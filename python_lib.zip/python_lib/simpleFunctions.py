def returnTrue():
    return True